# DiscordProtector
A bot to protect your discord server against raids
